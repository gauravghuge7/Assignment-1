import {useState} from 'react';
import './Counter.css';

// this is the counter function 
let z = 0;


function Counter() {

      const [x, setX] = useState(0);
      const [y, setY] = useState(0);
      return (
            <>    

                  
                  

                  <br/>
                  <br/>
                  
                  <h3>{x}</h3> 

                  <br/>
                  <button onClick={()=> setX(x+1)}>increment</button>
                  <button onClick={()=> setX(x-1)}>decrement</button>
                  
                  
                  <br/>
                  <br/>

            </>
      );
}

export default Counter;