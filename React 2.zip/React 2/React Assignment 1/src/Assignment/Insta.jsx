import {useState} from 'react';
import './Insta.css';


function Insta() {


      return (
            <> 
                <div>
                  <h3>instagram</h3>

                  <br />

                  <input type="text" placeholder='Phone number, username or email ' />
                  <br />
                  <input type="text" placeholder='Password'/>
                  <br />
                  <button>Sign in</button>
                </div>

            </>
      );
}

export default Insta;