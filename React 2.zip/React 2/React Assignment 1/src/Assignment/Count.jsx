

import {useState} from 'react';

import './Insta.css';



function Count() {


            
      <div>
      <h3>instagram</h3>

      <br />

      <input type="text" placeholder='Mobile number or email ' />
      <br />
      <input type="text" placeholder="Full Name" />
      <br />
      <input type="text" placeholder='Phone number, username or email ' />
      <br />
      <input type="text" placeholder='Password'/>
      <br />
      <button onClick={Count()}>Sign in</button>
    </div>
    
}