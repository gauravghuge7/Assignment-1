import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Counter from './Assignment/Counter.jsx';
import Insta from './Assignment/Count.jsx';
import Count from './Assignment/Insta.jsx';

function App() {
  

  return (
    <>
     <Count />
     <Insta />

        <Counter />

    </>
  )
}

export default App
